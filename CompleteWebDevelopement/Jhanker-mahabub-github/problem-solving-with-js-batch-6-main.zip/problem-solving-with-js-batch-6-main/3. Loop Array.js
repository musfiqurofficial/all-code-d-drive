const arr = [1, 2, 3, 6, 6, 3];

// for(let i = 0; i < arr.length; i++){
//   console.log(arr[i]);
// }
