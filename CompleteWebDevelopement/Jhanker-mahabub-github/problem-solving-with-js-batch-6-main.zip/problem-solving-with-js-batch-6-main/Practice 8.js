// Find the largest element of an array
