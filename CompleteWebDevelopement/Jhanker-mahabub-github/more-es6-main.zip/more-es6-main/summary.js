// 1. optional chaining
// student.marks?.math

// must
// 2. map, filter, find

// 3. (optional): forEach, reduce (advanced)

// 4. class

// 5. (optional) inheritance, super

// 6. (must) prototypical Inheritance