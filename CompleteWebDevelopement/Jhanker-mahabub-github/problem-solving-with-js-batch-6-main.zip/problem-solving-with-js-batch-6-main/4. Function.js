
let count = 5;

function name(c){
  for(let i = 5; i < 20; i++){
    return i;
  }
}



const result = name(count);

console.log(result)

