let first = 5;
let second = 7;


first = second;
// largest = element;

console.log(first)