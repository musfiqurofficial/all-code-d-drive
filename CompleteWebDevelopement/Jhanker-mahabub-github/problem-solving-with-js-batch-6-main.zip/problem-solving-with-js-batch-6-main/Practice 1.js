// Print all even numbers from 1 - 20

// write down the function structure
// think if any parameter is necessary
// how can i get all the values
// how can i get the even values only

function printEven(){
  for(let i = 1; i <= 20; i++){
    if(i % 2 == 0){
      console.log(i);
    }
  }
}

printEven();
