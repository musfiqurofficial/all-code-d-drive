// ভ্যারিয়েবল লেখার  জন্য  যা  যা  ব্যবহার  করতে  পারবেন

// 1. Letter(A-z)
// 2. Number {0-9}
// 3. UnderScore (_)
// 4. Doller ($)

// ভ্যারিয়েবল লেখার  জন্য  যা  যা  ব্যবহার  করতে  পারবেন না

// 1. কি  ওয়ার্ড  ব্যবহার  করা  যাবে  না

// 2. নম্বর  শুরুতেই  ব্যবহার  করা  যাবে  না
// 3. স্পেস  দেওয়া  যাবে  না

// 4. কেস  সেনসিটিভ  হওয়ায়  সেইম  টু  সেইম  হতে  হবে

// note :  CamelCase

var firstName = 74;

// data type for

// var test = false;

// console.log(typeof test);

// var number = "71.52";
// var number2 = 50;

// console.log(parseInt(number));

// console.log(parseFloat(number));

// if else state ment start

// var nayok = "hero alom";

// if (nayok == "hero alom") {
//   console.log("marbo bugurai lash porbe magurai ");
// } else if (nayok == "anonto") {
//   console.log("ami shob pari");
// } else {
//   console.log("i dont know");
// }

// if (false) {
//   console.log("yes true");
// }
// else {
//     console.log("its false")
// }

// var num = 100;

// if (robin >= 100) {
//   console.log("robin tumi iphone kino");
// } else {
//   console.log("robin tomar tho taka nai i phone ki diye kinba");
// }

// if (num > 100) {
//   console.log("num onek boro");
// } else if (num < 0) {
//   console.log("its negative");
// } else if (num == 100) {
//   console.log(" wow its ok");
// } else {
//   console.log("jani na");
// }

// var tamim = 80;

// if (tamim > 0) {
//   if (tamim == 80) {
//     console.log("yes i am from nested");
//   } else {
//     console.log("its not correct");
//   }
// } else {
//   console.log("mark can not be negative number");
// }

// 0-32 = F grade
// 33-39 = D
// 40-49 = C
// 50-59 = B
// 60-69 = A-
// 70-79 =A
// 80-95 = A+
// 96-100= Golden +

// var result = 4;

// if (result < 33 && result > 0) {
//   console.log(result, " tumi fail marco ricksha chalaw akkhon");
// } else if (result >= 33 && result < 40) {
//   console.log("Tumi D grade paiso ");
// } else if (result >= 40 && result < 50) {
//   console.log("tumi C grade paico ");
// } else {
// }

// switch
// switch, case,break,default,

// var name = "hero";

// switch (name) {
//   case "rahim":
//     console.log("wow its rahim");
//     break;
//   case "abdul":
//     console.log("tumi rahim na abdul");
//     break;
//   case "hero":
//     console.log("wow tumi hero");
//     break;
//   default:
//     console.log("dont know");
//     break;
// }

// var numbers = [1, "rahim", 3, 4, 5, "laili", 7, 8, 9];

// numbers.push("Dhaka");
// numbers.pop();

// numbers.shift();

// numbers.unshift("Bangladesh")

// numbers.reverse();
// numbers.join("-");
// numbers.join("-");

// console.log(numbers)
// for (var i = 1; i < 5; i++) {
//     console.log(i);
//   }

var friends = ["rahim", "adin", "jamila", "komolaaaa"];

// var i = 0;
// while (i < 10) {
//   console.log(i);
//   i++;
// }

// var temp = friends[0];

// for (var i = 0; i < friends.length; i++) {
    
//   var element = friends[i];
//   if (element.length > temp.length) {
//     temp = element;
//   }
// }

// console.log(temp);
